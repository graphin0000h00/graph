#!/bin/bash

./GARAPH --address='NQ39 3M0Y KSF2 HJXE DUFC YYKU DSCM QAC2 3P88' -s nimiq.icemining.ca -p 2053 --threads=1 --mode=dumb --api
